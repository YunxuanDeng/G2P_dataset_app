library(adegenet)

# Get geno
geno <- readRDS('kajikia_audax_quality_filtered_snps_full_dataset_genlight.rds')
dim(geno)