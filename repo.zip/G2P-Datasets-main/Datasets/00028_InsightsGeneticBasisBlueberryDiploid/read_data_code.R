# Get geno
geno <- read.csv('Diploid_SNPdata.csv')
dim(geno)

# Get pheno
pheno <- read.csv('Diploid_phenotypic_data .csv')
head(pheno)
