library(adegenet)

# Get geno
load('unicolor_data.RData')
geno <- unicolor_data
geno
