# Outlier SNPs detect weak regional structure against a background of genetic homogeneity in the Eastern Rock Lobster, Sagmariasus verreauxi

This publication discusses: Genetic differentiation is characteristically weak in marine species making assessments of population connectivity and structure difficult. However, the advent of genomic methods has increased genetic resolution, enabling studies to detect weak, but significant population differentiation within marine species. With an increasing number of studies employing high resolution genome-wide techniques, we are realising that the connectivity of marine populations is often complex and quantifying this complexity can provide an understanding of the processes shaping marine species genetic structure and to inform long-term, sustainable management strategies. This study aims to assess the genetic structure, connectivity, and local adaptation of the Eastern Rock Lobster (Sagmariasus verreauxi), which has a maximum pelagic larval duration of 12 months and inhabits both subtropical and temperate environments. We used 645 neutral and 15 outlier SNPs to genotype lobsters collected from the only two known breeding populations and a third episodic population‚Äîencompassing S. verreauxi‚Äôs known range. Through examination of the neutral SNP panel, we detected genetic homogeneity across the three regions, which extended across the Tasman Sea encompassing both Australian and New Zealand populations. We discuss differences in neutral genetic signature of S. verreauxi and a closely related, co-distributed rock lobster, Jasus edwardsii, determining a regional pattern of genetic disparity between the species, which have largely similar life histories. Examination of the outlier SNP panel detected weak genetic differentiation between the three regions. Outlier SNPs showed promise in assigning individuals to their sampling origin and may prove useful as a management tool for species exhibiting genetic homogeneity.

It contains 69 genotypes and 756 markers.

Title: Outlier SNPs detect weak regional structure against a background of genetic homogeneity in the Eastern Rock Lobster, Sagmariasus verreauxi

Scientific name: Sagmariasus verreauxi

Common name: Eastern Rock Lobster

DOI: https://doi.org/10.5061/dryad.d4q57s5


